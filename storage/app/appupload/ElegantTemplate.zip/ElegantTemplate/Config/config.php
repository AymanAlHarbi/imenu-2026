<?php

return [
    'name' => 'ElegantTemplate'
];
