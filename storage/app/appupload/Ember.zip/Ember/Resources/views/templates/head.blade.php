
<!-- head -->
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('argonfront') }}/img/apple-icon.png">
    <link rel="icon" type="image/png" href="{{ asset('argonfront') }}/img/favicon.png">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $restorant->name }}</title>
    <meta property="og:image" content="{{ $restorant->logom }}">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="590">
    <meta property="og:image:height" content="400">
    <meta name="og:title" property="og:title" content="{{ $restorant->name }}">
    <meta name="description" content="{{ $restorant->description }}">



    @notifyCss

    

    <!-- Select2 -->
    <link type="text/css" href="{{ asset('custom') }}/css/select2.min.css" rel="stylesheet">

   

    <!-- Global site tag (gtag.js) - Google Analytics -->
    @if (\Akaunting\Module\Facade::has('googleanalytics'))
        @include('googleanalytics::index') 
    @elseif (config('settings.google_analytics'))
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo config('settings.google_analytics'); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', '<?php echo config('settings.google_analytics'); ?>');
        </script>
    @endif

   

    @include('googletagmanager::head')
    @yield('head')
    @laravelPWA
    @include('layouts.rtl')
  

    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#EA580C">
    <meta name="msapplication-TileColor" content="#EA580C">
    <meta name="theme-color" content="#EA580C"  >

    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

    <link type="text/css" rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Custom CSS defined by admin -->
    <link type="text/css" href="{{ asset('byadmin') }}/front.css" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <link type="text/css" rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link type="text/css" href="{{ asset('css') }}/elegant.css" rel="stylesheet">
    
 
     <!-- Import Vue -->
    <script src="{{ asset('vendor') }}/vue/vue.js"></script>
    <!-- Import AXIOS --->
    <script src="{{ asset('vendor') }}/axios/axios.min.js"></script>

    @if (isset($showGoogleTranslate)&&$showGoogleTranslate&&!$showLanguagesSelector)
        <!-- Style  Google Translate -->
        <link type="text/css" href="{{ asset('custom') }}/css/gt.css" rel="stylesheet">
    @endif

    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet" />


 

    <!-- Ember theme: identity + 100% mobile overrides (loads after elegant.css; Ember pages only) -->
    <style id="ember-theme-overrides">
    :root{--ember:#EA580C;--ember-dark:#9A3412;--honey:#F59E0B;--canvas:#FAF6F0;--surface:#FFFFFF;--ink:#1C1917;--stone:#78716C;--line:#EFE7DC;}
    #wrapper{background:var(--canvas);}
    .section-place-content{background:var(--canvas)!important;}
    .box-infos{background:var(--surface);border:1px solid var(--line);}
    .place-card .info h1,.product-item_title{color:var(--ink);}
    .tag{background:#FAEEDA;color:#854F0B;border-radius:99px;padding:2px 8px;}
    .colorize,.colorize *{color:var(--ember)!important;}
    .ammount{color:var(--ember)!important;}
    .menu-tab.current{background:var(--ember)!important;color:#fff!important;}
    .btn-primary{background:var(--ember)!important;border-color:var(--ember)!important;color:#fff!important;}
    .btn-primary:hover,.btn-primary:focus,.btn-primary:active{background:var(--ember-dark)!important;border-color:var(--ember-dark)!important;}
    #mobile-menu{background:var(--canvas);}
    #mobile-menu .featured{color:var(--ember);}
    #mobile-menu .submenu .item a:hover{color:var(--ember);}
    #footer{background:var(--surface);border-top:1px solid var(--line);}
    .copyright,.copyright a{color:var(--stone);}
    ::selection{background:#FDE4D3;color:var(--ink);}
    input:focus,select:focus,textarea:focus,button:focus{outline:2px solid var(--ember);outline-offset:1px;}
    img,picture img,svg,iframe{max-width:100%;}
    .map iframe{width:100%!important;min-height:200px;border:0;}
    .section-place-header picture img{width:100%;}
    @media (max-width:768px){
      .section-place-content .packer{padding-left:12px!important;padding-right:12px!important;}
      .content-left,.content-center,.holder-left,.holder-right{width:100%!important;max-width:100%!important;float:none!important;}
      .holder-right{margin-top:16px;}
      .place-card .info h1{font-size:20px;}
      .schedule-map{flex-direction:column;}
      .schedule-map .map,.schedule-map .schedule{width:100%!important;}
      .box-infos{margin-right:0!important;}
      #footer .nav-footer{justify-content:center!important;}
    }
    </style>

</head>