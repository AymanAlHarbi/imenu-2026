<?php

return [
    'name' => 'LoyaltyPoints',
];
