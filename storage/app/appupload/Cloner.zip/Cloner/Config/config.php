<?php

return [
    'name' => 'Cloner'
];
