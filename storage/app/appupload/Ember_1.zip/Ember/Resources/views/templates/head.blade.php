
<!-- head -->
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('argonfront') }}/img/apple-icon.png">
    <link rel="icon" type="image/png" href="{{ asset('argonfront') }}/img/favicon.png">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $restorant->name }}</title>
    <meta property="og:image" content="{{ $restorant->logom }}">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="590">
    <meta property="og:image:height" content="400">
    <meta name="og:title" property="og:title" content="{{ $restorant->name }}">
    <meta name="description" content="{{ $restorant->description }}">



    @notifyCss

    

    <!-- Select2 -->
    <link type="text/css" href="{{ asset('custom') }}/css/select2.min.css" rel="stylesheet">

   

    <!-- Global site tag (gtag.js) - Google Analytics -->
    @if (\Akaunting\Module\Facade::has('googleanalytics'))
        @include('googleanalytics::index') 
    @elseif (config('settings.google_analytics'))
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo config('settings.google_analytics'); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', '<?php echo config('settings.google_analytics'); ?>');
        </script>
    @endif

   

    @include('googletagmanager::head')
    @yield('head')
    @laravelPWA
    @include('layouts.rtl')
  

    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#EA580C">
    <meta name="msapplication-TileColor" content="#EA580C">
    <meta name="theme-color" content="#EA580C"  >

    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

    <link type="text/css" rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Custom CSS defined by admin -->
    <link type="text/css" href="{{ asset('byadmin') }}/front.css" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <link type="text/css" rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    
 
     <!-- Import Vue -->
    <script src="{{ asset('vendor') }}/vue/vue.js"></script>
    <!-- Import AXIOS --->
    <script src="{{ asset('vendor') }}/axios/axios.min.js"></script>

    @if (isset($showGoogleTranslate)&&$showGoogleTranslate&&!$showLanguagesSelector)
        <!-- Style  Google Translate -->
        <link type="text/css" href="{{ asset('custom') }}/css/gt.css" rel="stylesheet">
    @endif

    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet" />


 

        <!-- Ember theme: standalone Bold-Appetite design (replaces elegant.css) -->
    <style id="ember-css">
/* ============================================================
   Ember theme  -  "Bold Appetite" standalone design system
   Self-contained: replaces elegant.css. Re-implements the tab
   + mobile-menu mechanics that eleganttemplate.js drives.
   ============================================================ */
:root{
  --em-canvas:#FBF3E9; --em-surface:#FFFFFF;
  --em-primary:#E23D28; --em-primary-d:#B83218; --em-accent:#E8A33D;
  --em-ink:#2A1E16; --em-muted:#8A7A6B; --em-line:#F0E2D2; --em-tint:#FBE2DB;
}
*{box-sizing:border-box;}
[v-cloak]{display:none;}
body{background:var(--em-canvas)!important;color:var(--em-ink);font-family:"Cairo","Segoe UI",system-ui,-apple-system,sans-serif;margin:0;}
#wrapper{background:var(--em-canvas);overflow-x:hidden;}
img,picture img,svg,iframe{max-width:100%;}
a{text-decoration:none;}

/* ---- Cover header ---- */
.em-cover{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;min-height:260px;padding:34px 16px 26px;background-size:cover;background-position:center;color:#fff;}
.em-cover::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(42,30,22,.30),rgba(178,50,24,.74));}
.em-cover>*{position:relative;z-index:1;}
.em-logo{width:74px;height:74px;border-radius:50%;border:3px solid #fff;background:#C23A22 center/cover no-repeat;display:flex;align-items:center;justify-content:center;margin-bottom:10px;}
.em-logo i{font-size:34px;color:#fff;}
.em-rest-name{font-size:30px;font-weight:700;line-height:1.2;margin:0;}
.em-rest-desc{font-size:14px;opacity:.92;margin:4px 0 0;}
.em-dir{display:inline-block;margin-top:8px;color:#FBD5C9;font-size:13px;text-decoration:underline;}
.em-tabs{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:18px;}
.em-tab{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:99px;background:rgba(255,255,255,.16);color:#fff;font-size:13px;font-weight:600;border:1px solid rgba(255,255,255,.4);cursor:pointer;}
.em-tab:hover{background:rgba(255,255,255,.28);color:#fff;}
.em-tab.is-active{background:#fff;color:var(--em-primary);border-color:#fff;}

/* ---- Tabs panels (driven by eleganttemplate.js) ---- */
.content-tab:not(.expanded){display:none!important;}

/* ---- Category quick-nav (sticky) ---- */
.em-langs{display:flex;gap:8px;flex-wrap:wrap;padding:12px 16px 0;}
.em-langs a{font-size:12px;color:var(--em-muted);border:1px solid var(--em-line);border-radius:99px;padding:4px 12px;background:#fff;}
.em-cats{position:sticky;top:0;z-index:30;display:flex;gap:8px;overflow-x:auto;padding:12px 16px;background:var(--em-canvas);border-bottom:1px solid var(--em-line);-webkit-overflow-scrolling:touch;}
.em-cats::-webkit-scrollbar{height:0;}
.em-chip{flex:0 0 auto;padding:7px 15px;border-radius:99px;background:#fff;border:1px solid var(--em-line);color:var(--em-ink);font-size:13px;font-weight:600;white-space:nowrap;}
.em-chip:hover{background:var(--em-primary);color:#fff;border-color:var(--em-primary);}

/* ---- Content layout ---- */
.em-content{display:flex;gap:24px;align-items:flex-start;max-width:1200px;margin:0 auto;padding:8px 16px 28px;}
.em-content-main{flex:1 1 auto;min-width:0;}
.em-aside{width:320px;flex:0 0 auto;position:sticky;top:14px;}
.em-sectitle{font-size:21px;font-weight:700;color:var(--em-ink);border-right:5px solid var(--em-primary);padding-right:12px;margin:26px 0 14px;}

/* ---- Item cards ---- */
.em-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;}
.em-card{display:flex;flex-direction:column;background:var(--em-surface);border:1px solid var(--em-line);border-radius:18px;overflow:hidden;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease;}
.em-card:hover{transform:translateY(-3px);box-shadow:0 14px 28px rgba(226,61,40,.13);border-color:#F4C9BF;}
.em-thumb{height:140px;background:var(--em-tint) center/cover no-repeat;display:flex;align-items:center;justify-content:center;}
.em-thumb i{font-size:38px;color:var(--em-primary);}
.em-cardbody{padding:13px;display:flex;flex-direction:column;flex:1 1 auto;}
.em-name{font-size:15px;font-weight:700;color:var(--em-ink);margin:0;}
.em-desc{font-size:12px;color:var(--em-muted);margin:3px 0 0;line-height:1.5;}
.em-pricerow{display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:10px;}
.em-prices{display:flex;align-items:baseline;gap:7px;}
.em-price{font-size:18px;font-weight:700;color:var(--em-primary);}
.em-old{font-size:12px;color:#B9A99A;text-decoration:line-through;}
.em-add{width:36px;height:36px;border-radius:50%;background:var(--em-primary);color:#fff;display:flex;align-items:center;justify-content:center;flex:0 0 auto;border:0;cursor:pointer;}
.em-add:hover{background:var(--em-primary-d);}
.em-add i{font-size:20px;}

/* ---- Cart (side + drawer) ---- */
.em-cart{background:var(--em-surface);border:1px solid var(--em-line);border-radius:18px;padding:16px;}
.em-cart-h{font-size:16px;font-weight:700;color:var(--em-ink);margin:0 0 12px;display:flex;align-items:center;gap:8px;}
.em-cart-item{padding:10px 0;border-bottom:1px solid var(--em-line);}
.em-cart-item .nm{font-size:13px;font-weight:700;color:var(--em-ink);margin:0;}
.em-cart-item .qt{font-size:12px;color:var(--em-muted);margin:2px 0 0;}
.em-cart-btns{display:flex;gap:6px;margin-top:6px;justify-content:flex-end;}
.em-cart-btns button{width:30px;height:30px;border-radius:9px;border:1px solid var(--em-line);background:#fff;color:var(--em-ink);display:flex;align-items:center;justify-content:center;cursor:pointer;}
.em-cart-btns button:hover{background:var(--em-tint);color:var(--em-primary);border-color:var(--em-primary);}
.em-cart-btns button svg{width:18px;height:18px;}
.em-cart-empty{font-size:13px;color:var(--em-muted);text-align:center;padding:10px 0;}
.em-subtotal{display:flex;align-items:center;justify-content:space-between;margin-top:12px;font-weight:700;color:var(--em-ink);}
.em-subtotal .v{color:var(--em-primary);}
.em-checkout{display:block;text-align:center;background:var(--em-primary);color:#fff;border-radius:12px;padding:12px;font-weight:700;margin-top:12px;}
.em-checkout:hover{background:var(--em-primary-d);color:#fff;}

/* ---- Bottom cart bar (mobile) ---- */
#cartButtonHolder{position:fixed;bottom:0;left:0;right:0;z-index:50;}
@media(min-width:1025px){#cartButtonHolder{display:none;}}
.em-bottombar-inner{display:flex;align-items:center;justify-content:space-between;background:var(--em-primary);color:#fff;padding:13px 18px;cursor:pointer;box-shadow:0 -6px 22px rgba(0,0,0,.16);}
.em-bottombar-inner .l{display:flex;align-items:center;gap:9px;font-size:14px;font-weight:700;}
.em-bottombar-inner .badge{background:#fff;color:var(--em-primary);border-radius:99px;min-width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;padding:0 6px;}
.em-bottombar-inner .r{font-size:14px;font-weight:700;}

/* ---- Info tab ---- */
.em-info{max-width:900px;margin:0 auto;padding:18px 16px 28px;}
.em-infocard{background:var(--em-surface);border:1px solid var(--em-line);border-radius:18px;padding:18px;}
.em-infocard h3{font-size:16px;font-weight:700;color:var(--em-ink);margin:0 0 4px;display:flex;align-items:center;gap:8px;}
.em-infocard p{margin:2px 0;color:var(--em-muted);font-size:14px;}
.em-hours{list-style:none;padding:0;margin:14px 0 0;}
.em-hours li{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--em-line);font-size:13px;}
.em-hours .day{color:var(--em-ink);font-weight:600;}
.em-hours .today{color:var(--em-primary);}
.em-hours .tag{background:var(--em-accent);color:#3A2607;border-radius:99px;font-size:10px;padding:1px 8px;margin-right:6px;}
.em-map{margin-top:14px;border-radius:14px;overflow:hidden;border:1px solid var(--em-line);}
.em-map iframe{width:100%;min-height:220px;border:0;display:block;}

/* ---- Product modal (Flowbite outer kept) ---- */
.em-modal{position:relative;width:100%;max-width:430px;margin:0 auto;background:var(--em-surface);border-radius:22px;overflow:hidden;max-height:88vh;overflow-y:auto;}
.em-modal-img{height:200px;background:var(--em-tint) center/cover no-repeat;}
.em-modal-body{padding:18px;}
.em-modal-title{font-size:21px;font-weight:700;color:var(--em-ink);margin:0;}
.em-modal-price{font-size:18px;font-weight:700;color:var(--em-primary);margin:6px 0 0;}
.em-modal-desc{font-size:14px;color:var(--em-muted);margin:10px 0 0;line-height:1.6;}
.em-modal-body label.lbl{display:block;font-size:13px;font-weight:700;color:var(--em-ink);margin:16px 0 6px;}
.em-qtyrow{display:flex;align-items:center;gap:12px;margin-top:14px;}
.em-qtyrow input{width:80px;height:42px;border:1px solid var(--em-line);border-radius:12px;text-align:center;font-size:15px;font-weight:700;color:var(--em-ink);}
.em-addbtn{width:100%;background:var(--em-primary);color:#fff;border:0;border-radius:14px;padding:13px;font-size:15px;font-weight:700;margin-top:16px;cursor:pointer;}
.em-addbtn:hover{background:var(--em-primary-d);}
.em-closed{display:block;margin-top:12px;font-size:13px;color:var(--em-accent);font-weight:600;}

/* ---- Social links bar ---- */
.em-social{display:flex;gap:18px;justify-content:center;flex-wrap:wrap;padding:16px;background:#fff;border-bottom:1px solid var(--em-line);}
.em-social a{color:var(--em-ink);display:inline-flex;}
.em-social a:hover{color:var(--em-primary);}

/* ---- Footer ---- */
#footer{background:var(--em-surface);border-top:1px solid var(--em-line);margin-top:10px;}
#footer .em-foot{max-width:1200px;margin:0 auto;padding:16px;}
#footer .nav{list-style:none;display:flex;gap:16px;flex-wrap:wrap;padding:0;margin:0;justify-content:center;}
#footer .nav a{color:var(--em-muted);font-size:13px;}
#footer .copyright{text-align:center;color:var(--em-muted);font-size:12px;padding:10px;border-top:1px solid var(--em-line);}

/* ---- Mobile menu drawer (driven by eleganttemplate.js) ---- */
#mobile-menu{position:fixed;inset:0;z-index:60;background:rgba(42,30,22,.55);display:none;}
body.mobile-menu-opened #mobile-menu{display:block;}
body.mobile-menu-opened{overflow:hidden;}
#mobile-menu>.content{position:absolute;top:0;right:0;height:100%;width:360px;max-width:88%;background:var(--em-canvas);overflow-y:auto;padding:18px;box-shadow:-12px 0 30px rgba(0,0,0,.18);}
#mobile-menu>.close-mobile-menu{position:fixed;top:16px;left:16px;width:46px;height:46px;border-radius:50%;background:#fff;color:var(--em-ink);display:inline-flex;align-items:center;justify-content:center;font-size:22px;}
#mobile-menu nav .item>a{display:flex;align-items:center;justify-content:space-between;padding:11px 4px;color:var(--em-ink);font-weight:600;font-size:14px;border-bottom:1px solid var(--em-line);}
#mobile-menu nav .item>a:hover{color:var(--em-primary);}
#mobile-menu nav .item .submenu{display:none;padding:4px 10px;}
#mobile-menu nav .item.expanded .submenu{display:block;}
#mobile-menu .featured{color:var(--em-primary);}
@media(min-width:993px){#mobile-menu{display:none!important;}}

/* ---- Responsive ---- */
@media(max-width:1024px){
  .em-aside{display:none;}
  .em-content-main{padding-bottom:72px;}
  .em-rest-name{font-size:26px;}
}
@media(max-width:560px){
  .em-grid{grid-template-columns:1fr 1fr;gap:12px;}
  .em-thumb{height:108px;}
  .em-name{font-size:13px;}
  .em-price{font-size:16px;}
  .em-cover{min-height:230px;}
}
@media(max-width:380px){
  .em-grid{grid-template-columns:1fr;}
}
    </style>

</head>